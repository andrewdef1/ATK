Bundle file ini saya kumpulkan dari :
http://webdesign.tutsplus.com/tutorials/creating-a-collection-of-css3-animated-pre-loaders--cms-21978
https://ihatetomatoes.net/create-custom-preloading-screen/

Silahkan bagikan. Jangan disalah gunakan. Saya tidak bertanggung jawab atas segala tuntutan penyalahgunaan bundle ini.
~Semoga bermanfaat~

http://www.syakirurohman.net